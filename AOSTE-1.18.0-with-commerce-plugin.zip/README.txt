AOSTE 1.18.0 + Commerce plugin bundle

This bundle contains two Halo installable components:
- theme-aoset-1.18.0.zip: install from Halo Console > Appearance > Themes.
- plugin-commerce-0.1.0-SNAPSHOT.jar: install from Halo Console > Plugins, then enable it.

The Commerce plugin requires Halo 2.26 or later. Enable the plugin before using the theme's commerce pages.
